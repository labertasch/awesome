module.exports = function(grunt) {
    grunt.initConfig({
        maven: {
            sling: {
                options: {
                    goal: 'install',
                    groupId: 'io.senol.awesome'

                },
                src: [ '**', '!node_modules/**' ]
            }

        }
    });

    grunt.loadNpmTasks('grunt-maven-tasks');

    grunt.registerTask('dev', [ 'maven:sling' ]);
};