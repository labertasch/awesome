package io.senol.awesome.stream.api;

/**
 * Created with IntelliJ IDEA.
 * User: stas
 * Date: 10/08/15
 * Time: 10:41
 * To change this template use File | Settings | File Templates.
 */
public interface StreamingServer {

}
