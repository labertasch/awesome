/**
 * awesome.js
 *
 * Date: 08, 2015
 * @Author stas
 */

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global jQuery, document, window */

var awesome = function (server) {
    this.server = server;
};

awesome.resolve = function (path, callback ) {
    var result = {};

    callback(result);
}

awesome.a = function () {

}




